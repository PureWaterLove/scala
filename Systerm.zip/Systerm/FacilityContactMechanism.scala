trait FacilityContactMechanism {//为设施和虚拟Site建立一个特质：设施联系机制（FacilityContactMechanism）
}
