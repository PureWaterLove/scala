trait Phenomenon {//现象
}
trait Party extends Phenomenon {//团体
}
trait Person extends Party{//个人
}
trait Organization extends Party{//组织
}
trait LegalOrganization extends Organization{//法定组织 在政府注册 法定组织有税号
}
trait Informalorganization extends Organization{//非正式组织
}