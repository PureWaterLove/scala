trait SiteStructure {//场所结构
}
trait SiteComposition extends SiteStructure{//合成结构
}
trait SiteCommunictionLink extends SiteStructure{//物理通信链接
}