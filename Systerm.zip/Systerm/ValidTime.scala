import java.util.Date

trait ValidTime {//有效时间
  val EffectiveDate: Date
  val UntilDate: Date
}
