import scala.util.matching.Regex

trait RulePhenomenon //有规则的现象 规则英文暂且用 Rule
{
  //val flag: Boolean

  var ruleLibrary: Map[String,Regex] //规则的库(字符串向正则表达式的映射)

  val ruleName: String //规则的名字

  var ruleType: Regex //规则类型

  def calibration ={  //规则匹配方法
  ruleName match {
    case `ruleName` => ruleType = ruleLibrary(ruleName)
    case _ => {println("没有符合此类型的规则");}
    }
  }
  def check: Boolean //校验方法
}
trait RuleString extends RulePhenomenon//有规则的字符串
{
  val s:String

  override var ruleLibrary: Map[ String, Regex ] = Map ( "email" -> new Regex("[a-zA-Z0-9]{4,}@[a-zA-Z0-9]{2,}.com"), "hanName" ->  new Regex("[a-zA-Z]{2,28}") )

  override def check: Boolean = {
    if(ruleType.pattern.matcher(s).matches()){
      println("1")
      true
    }else{
      println("0")
      false
    }
  }
}
case class Email(s:String) extends RuleString {
  override val ruleName: String = "email"
 // override val flag: Boolean = ruleType.pattern.matcher(s).matches()
  this.calibration
  this.check

  override var ruleType: Regex = _
}
case class Name(s:String)extends RuleString{
  override val ruleName: String = "hanName"

  this.calibration
  this.check

  override var ruleType: Regex = _
}


trait RuleFloat extends RulePhenomenon//有规则的浮点型
{
  override var ruleLibrary: Map[ String, Regex ] = Map("" -> new  Regex("[0-9]"))//???
}

trait Ruleenumeration extends RulePhenomenon//有规则的枚举
{

}