trait PartyRole {//团体角色管理
}
trait PersonRole extends PartyRole{//个人角色
}
/*以下为个人角色之子特质*/
trait Employee extends PersonRole{//雇员
}
trait Contractor extends PersonRole{//签约人
}
trait FamilyMember extends PersonRole{//家庭成员
}
trait Contact extends PersonRole{//联系人
}
//等等

trait OrganizationRole extends PartyRole{//组织角色
}
/*以下为组织角色之子特质*/
trait DistributionChannel extends OrganizationRole{//分销渠道
}
/*分销渠道特质之子特质*/
trait Agent extends DistributionChannel{//代理商
}
trait Distrbutor extends DistributionChannel{//分销商
}
/*分销渠道走特质结束*/

trait Partner extends OrganizationRole{//合作伙伴
}
trait Competitor extends OrganizationRole{//竞争对手
}
trait Household extends OrganizationRole{//住户
}
trait Regulator extends OrganizationRole{//管理机构
}
trait Supplier extends OrganizationRole{//供应商
}
trait Association extends OrganizationRole{//协会
}
trait OrganizationUnit extends OrganizationRole{//组织单位
}
/*组织单位子特质*/
trait ParentOrganization extends OrganizationUnit{//上级组织
}
trait Department extends OrganizationUnit{//部门
}
trait Division extends OrganizationUnit{//分支机构
}
trait Subsidiary extends OrganizationUnit{//分公司
}
/*组织单位子特质结束*/
trait InternalOrganization extends OrganizationRole{//内部组织
}
/*等等*/

trait CustomerRole extends PersonRole{//客户
}
/*以下为客户之子特质*/
trait BillToCustomer extends CustomerRole{//付款客户
}
trait ShipToCustomer extends CustomerRole{//装运目标客户
}
trait EndUserCustomer extends CustomerRole{//最终用户客户
}
/*等等*/

trait Prospect extends PersonRole{//潜在客户
}
trait Shareholder extends PersonRole{//股东
}
