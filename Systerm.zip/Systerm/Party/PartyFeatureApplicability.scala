trait PartyFeatureApplicability {//当事人特征适用性

}
