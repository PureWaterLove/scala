trait PartyClassification {//团体分类 当事人类别特质
}
trait PersonClassification extends PartyClassification{//个人分类
}
trait OrganizationClassification extends PartyClassification{//组织分类
}