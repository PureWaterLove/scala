trait PartyRelationship extends ValidTime{//团体关系管理 属性中有一个观察（起始日期、终止日期所组成的观察）与角色关联而不与Party直接关联
}
trait PersonRelationship extends PartyRelationship //个人关系管理
trait OrganizationRelationship extends PartyRelationship //组织关系管理

trait Employment extends PersonRelationship{//雇佣
}
trait CustomerRelationship extends OrganizationRelationship{//客户关系
}
trait OrganizationRollup extends PartyRelationship{//组织隶属关系
}
trait OrganizationContact extends PartyRelationship {//组织联络人关系
}
trait DistributionChannelRelationship extends PartyRelationship{//分销渠道关系
}
trait Partnership extends PartyRelationship{//合作关系
}
/*等等*/