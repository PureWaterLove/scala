trait PartyContactMechanism {//当事人联系机制  跟Party和Site分别进行关联
  // 起始日期和终止日期属性
}
