import java.sql.{Connection, DriverManager}

import akka.actor.Actor

trait Location {
}

trait Site extends Actor with Location{
  val locationType="Site"

}//场所
trait VirtualSite extends Site{}//虚拟场所

case class DatabaseInstanceStie(driver: String, url: String, username: String, password: String ) extends VirtualSite{
  var connection: Connection = null

  override def receive: Receive = {
    case "username"  => println(username)//显示用户名
    case "driver" => println(driver)//显示驱动
    case "password" => println(password)//显示密码
    case "closeDatabase" => {
      if (connection != null) {
        connection.close ()
      }
    } //关闭连接
    case "concatenonDatabase" => {
      try {
        Class.forName(driver)
        connection = DriverManager.getConnection ( url, username, password )
      }
      catch {
        case e: Exception => e.printStackTrace
      }
    } //连接数据库

    case _ => println("......................")
  }


}//数据库实例
class ServerSite extends VirtualSite {
  override def receive: Receive = ???
}//服务器实例
case class EmailSite (emails: String) extends VirtualSite{
  var flag:Boolean=_
  val email = new Email(emails)
  flag = email.check
  if(flag) println(flag)
  override def receive: Receive = {
      case _ => println ( this )
  }
}//电子邮件地址

case class WebSite(webSite:String) extends VirtualSite{
  override def receive: Receive = ???
}//网站地址
trait Telephone extends VirtualSite{}//电话
case class FixedLineTelephone (areaCode:String, telephoneNo:String/*区号加座机号*/) extends Telephone{
  override def receive: Receive = ???
}//固定电话
case class MobeleTelephone(MobileNumber:String/*固定十一位*/) extends Telephone{
  //https://tcc.taobao.com/cc/json/mobile_tel_segment.htm?tel=MobileNumber   查询手机号信息使用此接口
  override def receive: Receive = ???
}//移动电话
class InstantMessagingSite extends VirtualSite{
  override def receive: Receive = ???
}//即时通信地址?????

trait PhysicalSite extends Site{}//物理场所

class AddresSite extends PhysicalSite{
  override def receive: Receive = ???
}//街道地址
class PostalCodeSite(postalCode:String) extends PhysicalSite{
  override def receive: Receive = ???
}//邮编



//FacilityContactMechanism与VirtualSite和Facility 一个三元组

trait GeopoliticalArea extends Location{//地理位置
}
trait GeographicPoint extends GeopoliticalArea{//地点
}
trait GeographicArea extends GeopoliticalArea{//地理区域
}
trait Facility extends GeopoliticalArea{//设施
}
/*设施子特质*/
trait Warehouse extends Facility{//仓库
}
trait Plant extends Facility{//车间
}
trait Building extends Facility{//大楼
}
trait Floor extends Facility{//楼层
}
trait Office extends Facility{//办公室
}
trait Room extends Facility{//房间
}


