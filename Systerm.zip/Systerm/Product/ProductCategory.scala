trait ProductCategory {//产品类别
}
trait ProductUsageCategorization extends ProductCategory//产品用途
trait ParductIndustryCategorization extends ProductCategory//产品行业
trait ProductMaterialsCategorization extends ProductCategory//产品材料
