trait ProductFeatureApplicability {//产品特征适用性
//起始时间和截止时间
  //分别跟产品和产品特征关联
}
//子类ProductRequiredFeature、ProductStandardFeature、ProductOptionalFeature、ProductSelectableFeature