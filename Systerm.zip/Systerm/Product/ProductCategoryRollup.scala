trait ProductCategoryRollup {//产品类别隶属关系
//有两个属性，类型均是产品类别（ProductCategory）
}
