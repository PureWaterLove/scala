trait ProductPriceComponent {//价格成分 or 收费方式
//起始和终止日期
  //价格
}


trait OneTimeCharge extends ProductPriceComponent//
trait RecurringCharge extends ProductPriceComponent {//
  //重复性收费有一个收费的时间频度
}
trait UtilizationCharge extends ProductPriceComponent//