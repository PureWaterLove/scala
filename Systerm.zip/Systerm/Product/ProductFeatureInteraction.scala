trait ProductFeatureInteraction {//产品特征相互作用
//一方面跟产品关联，另一方面跟产品特征关联
}
trait ProductFeatureInteractionInteraction extends ProductFeatureInteraction//特征互相作用之间不兼容
trait ProductFeatureInteractionDependency extends ProductFeatureInteraction//特征相互作用之间依赖
