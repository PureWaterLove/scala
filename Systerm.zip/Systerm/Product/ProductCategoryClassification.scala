trait ProductCategoryClassification {//产品能类别分类
//起始和终止日期
}
//在产品能类别（ProductCategory）和产品（Product）之间进行关联