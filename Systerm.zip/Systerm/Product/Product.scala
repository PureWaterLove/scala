trait Product extends Phenomenon{//产品
  val ProductIdentifier:String//有规则的字符串 标识***
  val name:String
  //一个提出日期（IntroductionDate）一个销售终止日期（SalesDiscontinuationDate）一个支持终止日期（SupportDiscontinuationDate）和备注（Comment）
}
/*
* 企业需要知道大量的产品相关的信息，比如：
企业的服务或者货物的质量、价格与企业竞争对手的产品相比是咋样的
每个地点（比如门店、库房）需要多少库存才能满足客户的需要
企业所提供的服务或者货物的价格、成本、利润等等
企业在哪儿能够以最好的价格买到最好的服务或者货物*/
trait Gargo extends Product//货物
trait Service extends Product//服务
