trait ProductIdentification {//产品编码  子类型如条形码 ISBN码

}
