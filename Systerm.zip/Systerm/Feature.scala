trait Feature {//特征

}
trait PartyFeature extends Feature{//当事人特征  比如“婚姻状态”、“身高”、“性别”

}
trait ProductFeature extends Feature{//产品特征 产品质量、颜色、尺寸、大小、商标等等

}